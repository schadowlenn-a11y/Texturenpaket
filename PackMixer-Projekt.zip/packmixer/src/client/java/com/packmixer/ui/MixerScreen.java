package com.packmixer.ui;

import com.packmixer.core.Exporter;
import com.packmixer.core.PackFormat;
import com.packmixer.core.PackIndex;
import com.packmixer.core.PackSource;
import com.packmixer.core.Pix;
import com.packmixer.core.PreviewCache;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import net.fabricmc.loader.api.FabricLoader;

/**
 * Das PackMixer-Menü: links alle Texturen aller installierten Packs, rechts die Auswahl,
 * aus welchem Pack die Textur kommen soll. Unten: Export als neues Resource Pack.
 */
public class MixerScreen extends Screen {
	private static final int MARGIN = 8;
	private static final int ROW_H = 20;
	private static final int CAND_H = 40;
	private static final int CAND_HEADER = 26;

	private static final int WHITE = 0xFFFFFFFF;
	private static final int GRAY = 0xFFAAAAAA;
	private static final int GREEN = 0xFF55FF55;
	private static final int RED = 0xFFFF5555;

	private final Screen parent;
	private final PreviewCache previews = new PreviewCache();
	private final PackFormat.Info format = PackFormat.detect(MixerScreen.class);
	private final Path packDir = FabricLoader.getInstance().getGameDir().resolve("resourcepacks");

	private volatile PackIndex index;
	private volatile List<String> categories = List.of(PackIndex.ALL);
	private volatile String loadStatus = "Lade Packs ...";
	private volatile String status = "";
	private volatile boolean dirty = true;
	private volatile boolean exporting;
	private boolean closed;

	private int catIdx;
	private String search = "";
	private String exportName = "MeinPack";
	private final List<String> visible = new ArrayList<>();
	private int listScroll;
	private String selected;
	private int candScroll;
	/** Textur-Pfad -> gewähltes Pack. Fehlt ein Eintrag, bleibt die Textur Original (oder kommt vom Basis-Pack). */
	private final Map<String, PackSource> choices = new LinkedHashMap<>();
	private int applyIdx;
	private int baseIdx = -1;

	private EditBox searchBox;
	private EditBox nameBox;
	private Button catBtn;
	private Button packBtn;
	private Button baseBtn;
	private int catBtnW;
	private int quarterW;

	private int listX;
	private int listY;
	private int listW;
	private int listH;
	private int candX;
	private int candY;
	private int candW;
	private int candH;
	private int lastMouseX;
	private int lastMouseY;

	public MixerScreen(Screen parent) {
		super(Component.literal("PackMixer"));
		this.parent = parent;

		Thread scan = new Thread(() -> {
			PackIndex idx = PackIndex.scan(packDir, s -> loadStatus = s);
			synchronized (this) {
				if (closed) {
					idx.close();
					return;
				}
				categories = idx.categories();
				index = idx;
			}
			dirty = true;
		}, "PackMixer-Scan");
		scan.setDaemon(true);
		scan.start();
	}

	// ------------------------------------------------------------------ Aufbau

	@Override
	protected void init() {
		int m = MARGIN;
		int topW = this.width - 2 * m - 8;
		int searchW = topW * 55 / 100;
		catBtnW = topW - searchW;

		searchBox = new EditBox(this.font, m, 8, searchW, 20, Component.literal("Suche"));
		searchBox.setValue(search);
		searchBox.setResponder(s -> {
			search = s;
			listScroll = 0;
			dirty = true;
		});
		this.addRenderableWidget(searchBox);

		catBtn = Button.builder(Component.literal(""), b -> cycleCategory())
				.bounds(m + searchW + 8, 8, catBtnW, 20).build();
		this.addRenderableWidget(catBtn);

		quarterW = (this.width - 2 * m - 12) / 4;
		int rowA = this.height - 52;
		int rowB = this.height - 28;

		packBtn = Button.builder(Component.literal(""), b -> cyclePack())
				.bounds(m, rowA, quarterW, 20).build();
		this.addRenderableWidget(packBtn);
		this.addRenderableWidget(Button.builder(Component.literal(fit("Auf Liste anwenden", quarterW - 8)), b -> applyToVisible())
				.bounds(m + (quarterW + 4), rowA, quarterW, 20).build());
		this.addRenderableWidget(Button.builder(Component.literal(fit("Liste leeren", quarterW - 8)), b -> clearVisible())
				.bounds(m + 2 * (quarterW + 4), rowA, quarterW, 20).build());
		baseBtn = Button.builder(Component.literal(""), b -> cycleBase())
				.bounds(m + 3 * (quarterW + 4), rowA, quarterW, 20).build();
		this.addRenderableWidget(baseBtn);

		int nameW = (this.width - 2 * m) * 45 / 100;
		int rest = this.width - 2 * m - nameW - 8;
		int exportW = rest * 65 / 100;
		int backW = rest - exportW;
		nameBox = new EditBox(this.font, m, rowB, nameW, 20, Component.literal("Name"));
		nameBox.setValue(exportName);
		nameBox.setResponder(s -> exportName = s);
		this.addRenderableWidget(nameBox);
		this.addRenderableWidget(Button.builder(Component.literal(fit("Exportieren", exportW - 8)), b -> startExport())
				.bounds(m + nameW + 4, rowB, exportW, 20).build());
		this.addRenderableWidget(Button.builder(Component.literal(fit("Zurück", backW - 8)), b -> this.onClose())
				.bounds(m + nameW + 8 + exportW, rowB, backW, 20).build());

		int panelTop = 34;
		int panelBottom = Math.max(panelTop + 60, this.height - 70);
		listX = m;
		listY = panelTop;
		listW = (this.width - 2 * m - 8) * 55 / 100;
		listH = panelBottom - panelTop;
		candX = m + listW + 8;
		candY = panelTop;
		candW = this.width - m - candX;
		candH = listH;

		updateLabels();
	}

	private void updateLabels() {
		PackIndex idx = index;
		List<String> cats = categories;
		if (catBtn != null) {
			String cat = cats.get(Math.min(catIdx, cats.size() - 1));
			catBtn.setMessage(Component.literal(fit("Kategorie: " + cat, catBtnW - 8)));
		}
		if (packBtn != null) {
			String name = (idx == null || idx.packs.isEmpty()) ? "-" : idx.packs.get(applyIdx % idx.packs.size()).id;
			packBtn.setMessage(Component.literal(fit("Pack: " + name, quarterW - 8)));
		}
		if (baseBtn != null) {
			String name = (idx == null || baseIdx < 0 || baseIdx >= idx.packs.size()) ? "keins" : idx.packs.get(baseIdx).id;
			baseBtn.setMessage(Component.literal(fit("Basis: " + name, quarterW - 8)));
		}
	}

	private String fit(String s, int maxPx) {
		if (this.font.width(s) <= maxPx) {
			return s;
		}
		String cut = s;
		while (!cut.isEmpty() && this.font.width(cut + "...") > maxPx) {
			cut = cut.substring(0, cut.length() - 1);
		}
		return cut + "...";
	}

	// ------------------------------------------------------------------ Aktionen

	private void cycleCategory() {
		List<String> cats = categories;
		if (cats.size() > 1) {
			catIdx = (catIdx + 1) % cats.size();
			listScroll = 0;
			selected = null;
			dirty = true;
		}
	}

	private void cyclePack() {
		PackIndex idx = index;
		if (idx != null && !idx.packs.isEmpty()) {
			applyIdx = (applyIdx + 1) % idx.packs.size();
			updateLabels();
		}
	}

	private void cycleBase() {
		PackIndex idx = index;
		if (idx != null && !idx.packs.isEmpty()) {
			baseIdx++;
			if (baseIdx >= idx.packs.size()) {
				baseIdx = -1;
			}
			updateLabels();
		}
	}

	private void applyToVisible() {
		PackIndex idx = index;
		if (idx == null || idx.packs.isEmpty()) {
			return;
		}
		PackSource p = idx.packs.get(applyIdx % idx.packs.size());
		int n = 0;
		for (String path : visible) {
			if (idx.textures.get(path).contains(p)) {
				choices.put(path, p);
				n++;
			}
		}
		status = n + " von " + visible.size() + " Texturen aus " + p.id + " übernommen.";
	}

	private void clearVisible() {
		int n = 0;
		for (String path : visible) {
			if (choices.remove(path) != null) {
				n++;
			}
		}
		status = n + " Auswahl(en) entfernt.";
	}

	private void startExport() {
		PackIndex idx = index;
		if (idx == null || exporting) {
			return;
		}
		if (choices.isEmpty() && baseIdx < 0) {
			status = "Wähle zuerst Texturen aus (oder ein Basis-Pack).";
			return;
		}
		PackSource base = (baseIdx >= 0 && baseIdx < idx.packs.size()) ? idx.packs.get(baseIdx) : null;
		Map<String, PackSource> copy = new LinkedHashMap<>(choices);
		String name = exportName;
		exporting = true;
		status = "Exportiere ...";
		Thread t = new Thread(() -> {
			try {
				Exporter.Result r = Exporter.export(packDir, name, base, copy, format, s -> status = s);
				status = "Fertig: " + r.file().getFileName() + " (" + r.fileCount() + " Dateien). Jetzt im Resource-Pack-Menü aktivieren.";
			} catch (Exception e) {
				status = "Fehler: " + e.getMessage();
			} finally {
				exporting = false;
				synchronized (MixerScreen.this) {
					if (closed) {
						closePacks();
					}
				}
			}
		}, "PackMixer-Export");
		t.setDaemon(true);
		t.start();
	}

	private void refresh() {
		dirty = false;
		visible.clear();
		PackIndex idx = index;
		if (idx != null) {
			List<String> cats = categories;
			String cat = cats.get(Math.min(catIdx, cats.size() - 1));
			String q = search.trim().toLowerCase(Locale.ROOT);
			for (String path : idx.textures.keySet()) {
				if (!PackIndex.ALL.equals(cat) && !PackIndex.category(path).equals(cat)) {
					continue;
				}
				if (!q.isEmpty() && !PackIndex.displayName(path).toLowerCase(Locale.ROOT).contains(q)) {
					continue;
				}
				visible.add(path);
			}
			if (selected != null && !idx.textures.containsKey(selected)) {
				selected = null;
			}
		}
		listScroll = Math.max(0, Math.min(listScroll, maxListScroll()));
		updateLabels();
	}

	// ------------------------------------------------------------------ Zeichnen

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		lastMouseX = mouseX;
		lastMouseY = mouseY;
		if (dirty && index != null) {
			refresh();
		}
		super.extractRenderState(g, mouseX, mouseY, delta);

		drawPanel(g, listX, listY, listW, listH);
		drawPanel(g, candX, candY, candW, candH);

		PackIndex idx = index;
		if (idx == null) {
			g.text(this.font, fit(loadStatus, listW - 12), listX + 6, listY + 6, WHITE, true);
		} else if (idx.packs.isEmpty()) {
			drawLines(g, listX + 6, listY + 6, listW - 12, listY + listH - 4,
					"Keine Resource Packs gefunden.",
					"Lege .zip-Packs oder Pack-Ordner in den Ordner",
					"'resourcepacks' im Minecraft-Verzeichnis und",
					"öffne dieses Menü danach neu.");
		} else {
			drawList(g, idx, mouseX, mouseY);
			drawCandidates(g, idx, mouseX, mouseY);
		}

		int m = MARGIN;
		String info = visible.size() + " Texturen | " + choices.size() + " gewählt";
		int infoW = this.font.width(info);
		g.text(this.font, info, this.width - m - infoW, this.height - 66, GRAY, true);
		String msg = status;
		int color = msg.startsWith("Fehler") ? RED : (msg.startsWith("Fertig") ? GREEN : WHITE);
		g.text(this.font, fit(msg, this.width - 2 * m - infoW - 12), m, this.height - 66, color, true);
	}

	private void drawPanel(GuiGraphicsExtractor g, int x, int y, int w, int h) {
		g.fill(x, y, x + w, y + h, 0xAA000000);
		g.outline(x, y, w, h, 0xFF555555);
	}

	private void drawLines(GuiGraphicsExtractor g, int x, int y, int maxW, int maxY, String... lines) {
		int yy = y;
		for (String line : lines) {
			if (yy + this.font.lineHeight > maxY) {
				break;
			}
			g.text(this.font, fit(line, maxW), x, yy, GRAY, true);
			yy += this.font.lineHeight + 2;
		}
	}

	private void drawList(GuiGraphicsExtractor g, PackIndex idx, int mouseX, int mouseY) {
		if (visible.isEmpty()) {
			g.text(this.font, "Keine Texturen gefunden.", listX + 6, listY + 6, GRAY, true);
			return;
		}
		int rows = rowsFit();
		int textW = listW - 4 - 6 - 24;
		for (int i = 0; i < rows && listScroll + i < visible.size(); i++) {
			String path = visible.get(listScroll + i);
			int x = listX + 2;
			int y = listY + 2 + i * ROW_H;
			int w = listW - 4 - 6;
			boolean hover = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + ROW_H;
			if (path.equals(selected)) {
				g.fill(x, y, x + w, y + ROW_H, 0x66FFFFFF);
			} else if (hover) {
				g.fill(x, y, x + w, y + ROW_H, 0x33FFFFFF);
			}
			PackSource chosen = choices.get(path);
			drawPix(g, chosen == null ? null : previews.get(chosen, path), x + 2, y + 2, 16, chosen == null);
			g.text(this.font, fit(PackIndex.displayName(path), textW), x + 22, y + 1, WHITE, false);
			int n = idx.textures.get(path).size();
			if (chosen != null) {
				g.text(this.font, fit(chosen.id, textW), x + 22, y + 10, GREEN, false);
			} else {
				g.text(this.font, fit("Original | " + n + (n == 1 ? " Pack" : " Packs"), textW), x + 22, y + 10, GRAY, false);
			}
		}
		int max = maxListScroll();
		if (max > 0) {
			int trackX = listX + listW - 5;
			g.fill(trackX, listY + 2, trackX + 3, listY + listH - 2, 0x55FFFFFF);
			int thumbH = Math.max(8, (listH - 4) * rows / visible.size());
			int thumbY = listY + 2 + (listH - 4 - thumbH) * listScroll / max;
			g.fill(trackX, thumbY, trackX + 3, thumbY + thumbH, 0xFFCCCCCC);
		}
	}

	private void drawCandidates(GuiGraphicsExtractor g, PackIndex idx, int mouseX, int mouseY) {
		int x0 = candX + 6;
		int maxW = candW - 12;
		if (selected == null) {
			drawLines(g, x0, candY + 6, maxW, candY + candH - 4,
					"So geht's:",
					"1. Links Textur anklicken.",
					"2. Rechts das Pack wählen,",
					"    aus dem sie kommen soll.",
					"",
					"Schneller: Pack unten wählen,",
					"dann 'Auf Liste anwenden'.",
					"Das gilt für alle Texturen",
					"in der Liste (Suche und",
					"Kategorie filtern sie).",
					"",
					"Basis: Pack, das komplett",
					"mit Modellen und Sounds",
					"als Grundlage dient.");
			return;
		}
		List<PackSource> cands = idx.textures.get(selected);
		g.text(this.font, fit(PackIndex.displayName(selected), maxW), x0, candY + 4, WHITE, true);
		g.text(this.font, fit("Aus welchem Pack soll sie kommen?", maxW), x0, candY + 15, GRAY, true);

		int rows = candRowsFit();
		int items = cands.size() + 1;
		PackSource current = choices.get(selected);
		for (int k = 0; k < rows && candScroll + k < items; k++) {
			int i = candScroll + k;
			int x = candX + 2;
			int y = candY + CAND_HEADER + k * CAND_H;
			int w = candW - 4;
			boolean hover = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + CAND_H;
			boolean isChosen = i == 0 ? current == null : cands.get(i - 1) == current;
			if (isChosen) {
				g.fill(x, y, x + w, y + CAND_H - 2, 0x6633AA33);
			} else if (hover) {
				g.fill(x, y, x + w, y + CAND_H - 2, 0x33FFFFFF);
			}
			if (i == 0) {
				g.fill(x + 4, y + 4, x + 36, y + 36, 0xFF2B2B2B);
				g.text(this.font, "-", x + 18, y + 16, GRAY, false);
				g.text(this.font, fit("Original", w - 46), x + 42, y + 8, WHITE, false);
				g.text(this.font, fit("nichts ändern (Basis oder Vanilla)", w - 46), x + 42, y + 20, GRAY, false);
			} else {
				PackSource p = cands.get(i - 1);
				Pix pix = previews.get(p, selected);
				drawPix(g, pix, x + 4, y + 4, 32, false);
				g.text(this.font, fit(p.id, w - 46), x + 42, y + 8, WHITE, false);
				String res = (pix != null && !pix.failed()) ? pix.origWidth + " x " + pix.origHeight + " px" : (pix == null ? "lädt ..." : "nicht lesbar");
				g.text(this.font, fit(res, w - 46), x + 42, y + 20, GRAY, false);
			}
			if (isChosen) {
				g.text(this.font, "gewählt", x + w - this.font.width("gewählt") - 4, y + 8, GREEN, false);
			}
		}
	}

	/** Zeichnet eine Mini-Vorschau mit Rechtecken (Pixel gleicher Farbe in einer Zeile werden zusammengefasst). */
	private void drawPix(GuiGraphicsExtractor g, Pix p, int x, int y, int box, boolean empty) {
		g.fill(x, y, x + box, y + box, 0xFF2B2B2B);
		if (empty) {
			return;
		}
		if (p == null) {
			return;
		}
		if (p.failed()) {
			g.fill(x + 2, y + 2, x + box - 2, y + box - 2, 0xFF662222);
			return;
		}
		int s = Math.max(1, box / Math.max(p.width, p.height));
		int ox = x + (box - p.width * s) / 2;
		int oy = y + (box - p.height * s) / 2;
		for (int py = 0; py < p.height; py++) {
			int px = 0;
			while (px < p.width) {
				int c = p.argb[py * p.width + px];
				int run = 1;
				while (px + run < p.width && p.argb[py * p.width + px + run] == c) {
					run++;
				}
				if ((c >>> 24) != 0) {
					g.fill(ox + px * s, oy + py * s, ox + (px + run) * s, oy + (py + 1) * s, c);
				}
				px += run;
			}
		}
	}

	// ------------------------------------------------------------------ Eingaben

	private int rowsFit() {
		return Math.max(1, (listH - 4) / ROW_H);
	}

	private int candRowsFit() {
		return Math.max(1, (candH - CAND_HEADER - 2) / CAND_H);
	}

	private int maxListScroll() {
		return Math.max(0, visible.size() - rowsFit());
	}

	private int maxCandScroll() {
		PackIndex idx = index;
		if (idx == null || selected == null) {
			return 0;
		}
		return Math.max(0, idx.textures.get(selected).size() + 1 - candRowsFit());
	}

	private static boolean inside(int mx, int my, int x, int y, int w, int h) {
		return mx >= x && mx < x + w && my >= y && my < y + h;
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (super.mouseClicked(event, doubleClick)) {
			return true;
		}
		// Position vom letzten gezeichneten Bild, so brauchen wir keine Details des Events.
		int mx = lastMouseX;
		int my = lastMouseY;
		PackIndex idx = index;
		if (idx == null) {
			return false;
		}
		if (inside(mx, my, listX, listY + 2, listW - 6, listH - 2)) {
			int i = listScroll + (my - listY - 2) / ROW_H;
			if (i < visible.size() && (my - listY - 2) / ROW_H < rowsFit()) {
				selected = visible.get(i);
				candScroll = 0;
				return true;
			}
		} else if (selected != null && inside(mx, my, candX, candY + CAND_HEADER, candW, candH - CAND_HEADER)) {
			int k = (my - candY - CAND_HEADER) / CAND_H;
			int i = candScroll + k;
			List<PackSource> cands = idx.textures.get(selected);
			if (k < candRowsFit() && i <= cands.size()) {
				if (i == 0) {
					choices.remove(selected);
				} else {
					choices.put(selected, cands.get(i - 1));
				}
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
		if (index != null) {
			int dir = scrollY > 0 ? -1 : 1;
			if (inside(lastMouseX, lastMouseY, listX, listY, listW, listH)) {
				listScroll = Math.max(0, Math.min(maxListScroll(), listScroll + dir * 3));
				return true;
			}
			if (inside(lastMouseX, lastMouseY, candX, candY, candW, candH)) {
				candScroll = Math.max(0, Math.min(maxCandScroll(), candScroll + dir));
				return true;
			}
		}
		return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
	}

	@Override
	public void onClose() {
		synchronized (this) {
			closed = true;
			if (!exporting) {
				closePacks();
			}
		}
		this.minecraft.gui.setScreen(this.parent);
	}

	/** Beim Export bleiben die Packs offen, bis er fertig ist (siehe startExport). */
	private void closePacks() {
		previews.shutdown();
		PackIndex idx = index;
		if (idx != null) {
			idx.close();
		}
	}
}
