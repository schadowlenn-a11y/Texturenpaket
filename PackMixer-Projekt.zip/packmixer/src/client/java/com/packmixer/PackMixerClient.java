package com.packmixer;

import com.mojang.blaze3d.platform.InputConstants;
import com.packmixer.ui.MixerScreen;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;

public class PackMixerClient implements ClientModInitializer {
	public static final String MOD_ID = "packmixer";

	private static KeyMapping openKey;

	@Override
	public void onInitializeClient() {
		// Taste (Standard: J, in den Steuerungs-Einstellungen änderbar), öffnet das Menü aus dem Spiel oder Hauptmenü.
		KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));
		openKey = KeyMappingHelper.registerKeyMapping(
				new KeyMapping("key.packmixer.open", InputConstants.Type.KEYSYM, InputConstants.KEY_J, category));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openKey.consumeClick()) {
				client.gui.setScreen(new MixerScreen(null));
			}
		});

		// Zusätzlich ein Knopf oben links im normalen Resource-Pack-Menü.
		ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
			if (screen.getClass().getSimpleName().equals("PackSelectionScreen")) {
				Button button = Button.builder(Component.literal("PackMixer"), b -> client.gui.setScreen(new MixerScreen(screen)))
						.bounds(6, 6, 80, 20).build();
				Screens.getWidgets(screen).add(button);
			}
		});
	}
}
