package com.packmixer.core;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Lädt Textur-Vorschauen im Hintergrund, damit das Menü nicht ruckelt. */
public final class PreviewCache {
	private static final long MAX_BYTES = 8L * 1024 * 1024;

	private final ConcurrentHashMap<String, Pix> done = new ConcurrentHashMap<>();
	private final ConcurrentHashMap<String, Boolean> started = new ConcurrentHashMap<>();
	private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
		Thread t = new Thread(r, "PackMixer-Vorschau");
		t.setDaemon(true);
		return t;
	});

	/** Gibt die Vorschau zurück, oder null solange sie noch lädt. */
	public Pix get(PackSource pack, String path) {
		String key = pack.id + "\n" + path;
		Pix ready = done.get(key);
		if (ready != null) {
			return ready;
		}
		if (started.putIfAbsent(key, Boolean.TRUE) == null) {
			executor.execute(() -> {
				Pix result;
				try {
					long size = pack.size(path);
					result = (size < 0 || size > MAX_BYTES) ? Pix.FAILED : Pix.decode(pack.read(path));
				} catch (Exception | OutOfMemoryError e) {
					result = Pix.FAILED;
				}
				if (done.size() > 6000) {
					done.clear();
					started.clear();
				}
				done.put(key, result);
			});
		}
		return null;
	}

	public void shutdown() {
		executor.shutdownNow();
	}
}
