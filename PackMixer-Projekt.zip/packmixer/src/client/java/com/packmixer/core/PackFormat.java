package com.packmixer.core;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Findet heraus, welches Resource-Pack-Format das laufende Minecraft erwartet (steht in der version.json
 * des Spiels). Ohne das würde das exportierte Pack im Menü als "inkompatibel" angezeigt.
 */
public final class PackFormat {
	/** major = Formatnummer; modern = pack.mcmeta mit min_format/max_format (ab 1.21.9); detected = wirklich erkannt. */
	public record Info(int major, boolean modern, boolean detected) {}

	/** Falls die Erkennung scheitert: das Pack lässt sich trotzdem aktivieren, zeigt aber eine Warnung. */
	public static final Info FALLBACK = new Info(75, false, false);

	private PackFormat() {}

	public static Info detect(Class<?> anyClass) {
		try (InputStream in = anyClass.getResourceAsStream("/version.json")) {
			if (in == null) {
				return FALLBACK;
			}
			return parse(new String(in.readAllBytes(), StandardCharsets.UTF_8));
		} catch (Exception e) {
			return FALLBACK;
		}
	}

	/** Getrennt von detect(), damit es sich testen lässt. */
	public static Info parse(String json) {
		try {
			JsonObject root = JsonParser.parseString(json).getAsJsonObject();
			JsonElement pv = root.get("pack_version");
			if (pv != null && pv.isJsonObject()) {
				JsonObject o = pv.getAsJsonObject();
				if (o.has("resource_major")) {
					return new Info(o.get("resource_major").getAsInt(), true, true);
				}
				if (o.has("resource")) {
					return new Info(o.get("resource").getAsInt(), false, true);
				}
			}
			if (root.has("resource_pack_version")) {
				return new Info(root.get("resource_pack_version").getAsInt(), true, true);
			}
		} catch (Exception ignored) {
			// fällt unten auf FALLBACK zurück
		}
		return FALLBACK;
	}

	/** Inhalt der pack.mcmeta. */
	public static String mcmeta(Info info, String description) {
		String desc = description.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ");
		StringBuilder sb = new StringBuilder();
		sb.append("{\n  \"pack\": {\n");
		sb.append("    \"description\": \"").append(desc).append("\",\n");
		if (info.modern()) {
			sb.append("    \"min_format\": ").append(info.major()).append(",\n");
			sb.append("    \"max_format\": ").append(info.major()).append("\n");
		} else {
			sb.append("    \"pack_format\": ").append(info.major()).append("\n");
		}
		sb.append("  }\n}\n");
		return sb.toString();
	}
}
