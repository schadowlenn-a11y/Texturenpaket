package com.packmixer.core;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.Consumer;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Baut aus den gewählten Texturen ein neues Resource Pack (ZIP). */
public final class Exporter {
	public record Result(Path file, int fileCount) {}

	private Exporter() {}

	public static Result export(Path outDir, String requestedName, PackSource base, Map<String, PackSource> choices,
			PackFormat.Info format, Consumer<String> progress) throws IOException {
		if (choices.isEmpty() && base == null) {
			throw new IOException("Es ist noch nichts ausgewählt.");
		}
		Files.createDirectories(outDir);

		// Pfad im neuen Pack -> Quelle. TreeMap = feste, sortierte Reihenfolge.
		Map<String, PackSource> files = new TreeMap<>();
		if (base != null) {
			for (String rel : base.files()) {
				if (rel.startsWith("assets/")) {
					files.put(rel, base);
				}
			}
		}
		for (Map.Entry<String, PackSource> e : choices.entrySet()) {
			String tex = e.getKey();
			PackSource src = e.getValue();
			files.put(tex, src);
			// Animationsdatei (z. B. fire_0.png.mcmeta) gehört zur Textur und kommt vom selben Pack.
			String meta = tex + ".mcmeta";
			if (src.has(meta)) {
				files.put(meta, src);
			} else {
				files.remove(meta);
			}
		}

		String name = sanitize(requestedName);
		Path target = uniqueFile(outDir, name);
		Path tmp = outDir.resolve(target.getFileName() + ".part");

		Map<String, Integer> perPack = new LinkedHashMap<>();
		for (PackSource s : files.values()) {
			perPack.merge(s.id, 1, Integer::sum);
		}

		int written = 0;
		try (ZipOutputStream zos = new ZipOutputStream(Files.newOutputStream(tmp))) {
			zos.setLevel(6);
			putText(zos, "pack.mcmeta", PackFormat.mcmeta(format, "Mit PackMixer zusammengestellt"));
			putText(zos, "CREDITS.txt", credits(perPack, base));
			if (base != null && base.has("pack.png")) {
				putBytes(zos, "pack.png", base.read("pack.png"));
			}
			int total = files.size();
			for (Map.Entry<String, PackSource> e : files.entrySet()) {
				zos.putNextEntry(new ZipEntry(e.getKey()));
				try (InputStream in = e.getValue().openStream(e.getKey())) {
					in.transferTo(zos);
				}
				zos.closeEntry();
				written++;
				if (written % 200 == 0) {
					progress.accept("Schreibe " + written + " / " + total);
				}
			}
		} catch (IOException | RuntimeException ex) {
			Files.deleteIfExists(tmp);
			throw ex;
		}
		Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
		return new Result(target, written);
	}

	static String credits(Map<String, Integer> perPack, PackSource base) {
		StringBuilder sb = new StringBuilder();
		sb.append("Dieses Pack wurde mit PackMixer aus mehreren Resource Packs zusammengestellt.\n");
		sb.append("Die Rechte an den Texturen liegen bei den Erstellern der Original-Packs.\n");
		sb.append("Bitte gib dieses Pack nur weiter, wenn die Lizenzen der Original-Packs das erlauben.\n\n");
		if (base != null) {
			sb.append("Basis-Pack: ").append(base.id).append("\n\n");
		}
		sb.append("Enthaltene Dateien pro Pack:\n");
		List<String> lines = new ArrayList<>();
		for (Map.Entry<String, Integer> e : perPack.entrySet()) {
			lines.add("- " + e.getKey() + ": " + e.getValue());
		}
		lines.sort(String.CASE_INSENSITIVE_ORDER);
		for (String l : lines) {
			sb.append(l).append("\n");
		}
		return sb.toString();
	}

	public static String sanitize(String raw) {
		String s = raw == null ? "" : raw.trim();
		StringBuilder sb = new StringBuilder();
		for (char c : s.toCharArray()) {
			if (Character.isLetterOrDigit(c) || c == '_' || c == '-' || c == '.') {
				sb.append(c);
			} else if (c == ' ') {
				sb.append('_');
			}
		}
		String out = sb.toString();
		while (out.startsWith(".")) {
			out = out.substring(1);
		}
		if (out.toLowerCase(Locale.ROOT).endsWith(".zip")) {
			out = out.substring(0, out.length() - 4);
		}
		if (out.length() > 48) {
			out = out.substring(0, 48);
		}
		return out.isEmpty() ? "PackMixer" : out;
	}

	/** Überschreibt nie ein bestehendes Pack (es könnte gerade im Spiel aktiv und gesperrt sein). */
	static Path uniqueFile(Path dir, String name) {
		Path p = dir.resolve(name + ".zip");
		int i = 2;
		while (Files.exists(p)) {
			p = dir.resolve(name + "_" + i + ".zip");
			i++;
		}
		return p;
	}

	private static void putText(ZipOutputStream zos, String name, String text) throws IOException {
		putBytes(zos, name, text.getBytes(StandardCharsets.UTF_8));
	}

	private static void putBytes(ZipOutputStream zos, String name, byte[] data) throws IOException {
		zos.putNextEntry(new ZipEntry(name));
		zos.write(data);
		zos.closeEntry();
	}
}
