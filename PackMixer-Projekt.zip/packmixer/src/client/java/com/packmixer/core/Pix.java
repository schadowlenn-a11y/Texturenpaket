package com.packmixer.core;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 * Kleine Vorschau einer Textur (höchstens 16x16 Pixel). Wird später mit Rechtecken gezeichnet,
 * dadurch braucht die Vorschau keine Minecraft-Texturen-API.
 */
public final class Pix {
	/** Platzhalter, wenn sich eine Textur nicht lesen lässt. */
	public static final Pix FAILED = new Pix(0, 0, 0, 0, new int[0]);

	public static final int MAX = 16;

	public final int width;
	public final int height;
	public final int origWidth;
	public final int origHeight;
	/** ARGB */
	public final int[] argb;

	private Pix(int width, int height, int origWidth, int origHeight, int[] argb) {
		this.width = width;
		this.height = height;
		this.origWidth = origWidth;
		this.origHeight = origHeight;
		this.argb = argb;
	}

	public boolean failed() {
		return width == 0;
	}

	public static Pix decode(byte[] png) throws IOException {
		BufferedImage img = ImageIO.read(new ByteArrayInputStream(png));
		if (img == null) {
			return FAILED;
		}
		int ow = img.getWidth();
		int oh = img.getHeight();
		int w = ow;
		int h = oh;
		// Animierte Texturen sind ein senkrechter Streifen: nur das erste Bild zeigen.
		if (h > w) {
			h = w;
		}
		if (w <= MAX && h <= MAX) {
			int[] px = new int[w * h];
			for (int y = 0; y < h; y++) {
				for (int x = 0; x < w; x++) {
					px[y * w + x] = img.getRGB(x, y);
				}
			}
			return new Pix(w, h, ow, oh, px);
		}
		double f = (double) MAX / Math.max(w, h);
		int tw = Math.max(1, (int) Math.round(w * f));
		int th = Math.max(1, (int) Math.round(h * f));
		int[] px = new int[tw * th];
		for (int ty = 0; ty < th; ty++) {
			int y0 = (int) Math.floor(ty / f);
			int y1 = Math.max(y0 + 1, Math.min(h, (int) Math.floor((ty + 1) / f)));
			for (int tx = 0; tx < tw; tx++) {
				int x0 = (int) Math.floor(tx / f);
				int x1 = Math.max(x0 + 1, Math.min(w, (int) Math.floor((tx + 1) / f)));
				long a = 0;
				long r = 0;
				long g = 0;
				long b = 0;
				int n = 0;
				for (int y = y0; y < y1 && y < h; y++) {
					for (int x = x0; x < x1 && x < w; x++) {
						int c = img.getRGB(x, y);
						int ca = c >>> 24;
						a += ca;
						// nach Alpha gewichten, damit durchsichtige Ränder die Farbe nicht verfälschen
						r += (long) ((c >> 16) & 0xFF) * ca;
						g += (long) ((c >> 8) & 0xFF) * ca;
						b += (long) (c & 0xFF) * ca;
						n++;
					}
				}
				if (n == 0 || a == 0) {
					px[ty * tw + tx] = 0;
				} else {
					int oa = (int) (a / n);
					int or = (int) (r / a);
					int og = (int) (g / a);
					int ob = (int) (b / a);
					px[ty * tw + tx] = (oa << 24) | (or << 16) | (og << 8) | ob;
				}
			}
		}
		return new Pix(tw, th, ow, oh, px);
	}
}
