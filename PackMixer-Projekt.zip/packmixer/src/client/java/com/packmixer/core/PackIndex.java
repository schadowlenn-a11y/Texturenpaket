package com.packmixer.core;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.function.Consumer;
import java.util.stream.Stream;

/** Durchsucht den resourcepacks-Ordner und merkt sich, welches Pack welche Textur enthält. */
public final class PackIndex {
	public static final String ALL = "Alle";

	public final List<PackSource> packs = new ArrayList<>();
	/** Textur-Pfad (z. B. assets/minecraft/textures/block/stone.png) -> Packs, die diese Textur enthalten. */
	public final Map<String, List<PackSource>> textures = new TreeMap<>();
	public final List<String> problems = new ArrayList<>();
	public int skipped;

	public static PackIndex scan(Path dir, Consumer<String> progress) {
		PackIndex index = new PackIndex();
		if (!Files.isDirectory(dir)) {
			index.problems.add("Ordner nicht gefunden: " + dir);
			return index;
		}
		List<Path> candidates = new ArrayList<>();
		try (Stream<Path> list = Files.list(dir)) {
			list.forEach(p -> {
				String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
				if (n.startsWith(".") || n.endsWith(".tmp") || n.endsWith(".part")) {
					return;
				}
				if (Files.isDirectory(p) || n.endsWith(".zip")) {
					candidates.add(p);
				}
			});
		} catch (IOException e) {
			index.problems.add("Ordner nicht lesbar: " + e.getMessage());
			return index;
		}
		candidates.sort(Comparator.comparing(p -> p.getFileName().toString().toLowerCase(Locale.ROOT)));

		int done = 0;
		for (Path p : candidates) {
			done++;
			progress.accept("Lese " + p.getFileName() + " (" + done + "/" + candidates.size() + ")");
			try {
				PackSource pack = PackSource.open(p);
				if (pack == null) {
					index.skipped++;
					continue;
				}
				int count = 0;
				for (String rel : pack.files()) {
					if (isTexture(rel)) {
						index.textures.computeIfAbsent(rel, k -> new ArrayList<>()).add(pack);
						count++;
					}
				}
				if (count == 0) {
					pack.close();
					index.skipped++;
				} else {
					index.packs.add(pack);
				}
			} catch (IOException | RuntimeException e) {
				index.problems.add(p.getFileName() + ": " + e.getMessage());
			}
		}
		return index;
	}

	/** Alle Kategorien (erster Unterordner unter textures/), vorne "Alle". */
	public List<String> categories() {
		TreeSet<String> set = new TreeSet<>();
		for (String path : textures.keySet()) {
			set.add(category(path));
		}
		List<String> out = new ArrayList<>();
		out.add(ALL);
		out.addAll(set);
		return out;
	}

	public void close() {
		for (PackSource p : packs) {
			p.close();
		}
	}

	/** Zählt als Textur: assets/&lt;namespace&gt;/textures/**.png */
	public static boolean isTexture(String rel) {
		if (!rel.endsWith(".png")) {
			return false;
		}
		String[] parts = rel.split("/");
		return parts.length >= 5 && parts[0].equals("assets") && parts[2].equals("textures");
	}

	/** block, item, entity, gui ... oder "(allgemein)" für Dateien direkt in textures/. */
	public static String category(String path) {
		String[] parts = path.split("/");
		if (parts.length <= 4) {
			return "(allgemein)";
		}
		String cat = parts[3];
		return parts[1].equals("minecraft") ? cat : parts[1] + ":" + cat;
	}

	/** Kurzer Anzeigename: block/stone.png (minecraft) bzw. namespace:block/stone.png. */
	public static String displayName(String path) {
		String[] parts = path.split("/", 4);
		if (parts.length < 4) {
			return path;
		}
		return parts[1].equals("minecraft") ? parts[3] : parts[1] + ":" + parts[3];
	}
}
