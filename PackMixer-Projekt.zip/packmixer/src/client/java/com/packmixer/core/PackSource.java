package com.packmixer.core;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Ein installiertes Resource Pack (ZIP-Datei oder entpackter Ordner).
 * Kennt nur Dateipfade relativ zur Pack-Wurzel, z. B. "assets/minecraft/textures/block/stone.png".
 * Enthält bewusst keinen Minecraft-Code, damit es sich ohne Spiel testen lässt.
 */
public final class PackSource implements AutoCloseable {
	public final String id;
	private final Path path;
	private final boolean zip;

	/** normalisierter Pfad (relativ zur Pack-Wurzel) -> Originalname im ZIP (bzw. gleicher Pfad bei Ordnern) */
	private final Map<String, String> names = new HashMap<>();
	private String prefix = "";
	private ZipFile zipFile;

	private PackSource(String id, Path path, boolean zip) {
		this.id = id;
		this.path = path;
		this.zip = zip;
	}

	/** Liest ein Pack ein. Gibt null zurück, wenn es kein gültiges Resource Pack ist. */
	public static PackSource open(Path path) throws IOException {
		boolean isZip = Files.isRegularFile(path);
		PackSource pack = new PackSource(path.getFileName().toString(), path, isZip);
		boolean valid = isZip ? pack.listZip() : pack.listFolder();
		if (!valid) {
			pack.close();
			return null;
		}
		return pack;
	}

	private boolean listZip() throws IOException {
		ZipFile zf = zip();
		List<String> raw = new ArrayList<>();
		var en = zf.entries();
		while (en.hasMoreElements()) {
			ZipEntry e = en.nextElement();
			if (!e.isDirectory()) {
				raw.add(e.getName());
			}
		}
		// Wurzel finden: flachste pack.mcmeta. Manche ZIPs enthalten noch einen Ordner drumherum.
		String best = null;
		for (String n : raw) {
			String norm = n.replace('\\', '/');
			if (norm.equals("pack.mcmeta") || norm.endsWith("/pack.mcmeta")) {
				String p = norm.substring(0, norm.length() - "pack.mcmeta".length());
				if (best == null || p.length() < best.length()) {
					best = p;
				}
			}
		}
		if (best == null) {
			for (String n : raw) {
				if (n.replace('\\', '/').startsWith("assets/")) {
					best = "";
					break;
				}
			}
		}
		if (best == null) {
			return false;
		}
		prefix = best;
		for (String n : raw) {
			String norm = n.replace('\\', '/');
			if (norm.startsWith(prefix)) {
				names.put(norm.substring(prefix.length()), n);
			}
		}
		return true;
	}

	private boolean listFolder() throws IOException {
		if (!Files.isDirectory(path)) {
			return false;
		}
		boolean valid = Files.isRegularFile(path.resolve("pack.mcmeta")) || Files.isDirectory(path.resolve("assets"));
		if (!valid) {
			return false;
		}
		try (Stream<Path> walk = Files.walk(path)) {
			walk.filter(Files::isRegularFile).forEach(p -> {
				String rel = path.relativize(p).toString().replace('\\', '/');
				names.put(rel, rel);
			});
		}
		return true;
	}

	private synchronized ZipFile zip() throws IOException {
		if (zipFile == null) {
			zipFile = new ZipFile(path.toFile());
		}
		return zipFile;
	}

	/** Alle Dateien des Packs (relative Pfade, mit '/'). */
	public Set<String> files() {
		return Collections.unmodifiableSet(new HashSet<>(names.keySet()));
	}

	public boolean has(String rel) {
		return names.containsKey(rel);
	}

	public long size(String rel) throws IOException {
		String name = names.get(rel);
		if (name == null) {
			return -1;
		}
		if (zip) {
			ZipEntry e = zip().getEntry(name);
			return e == null ? -1 : e.getSize();
		}
		return Files.size(path.resolve(name));
	}

	public InputStream openStream(String rel) throws IOException {
		String name = names.get(rel);
		if (name == null) {
			throw new IOException("Datei nicht im Pack: " + rel);
		}
		if (zip) {
			ZipEntry e = zip().getEntry(name);
			if (e == null) {
				throw new IOException("Eintrag fehlt: " + name);
			}
			return zip().getInputStream(e);
		}
		return Files.newInputStream(path.resolve(name));
	}

	public byte[] read(String rel) throws IOException {
		try (InputStream in = openStream(rel)) {
			return in.readAllBytes();
		}
	}

	@Override
	public synchronized void close() {
		if (zipFile != null) {
			try {
				zipFile.close();
			} catch (IOException ignored) {
				// nichts zu tun
			}
			zipFile = null;
		}
	}

	@Override
	public String toString() {
		return id;
	}
}
